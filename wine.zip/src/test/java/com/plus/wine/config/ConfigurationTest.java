package com.plus.wine.config;

import static org.junit.jupiter.api.Assertions.*;

class ConfigurationTest {

}