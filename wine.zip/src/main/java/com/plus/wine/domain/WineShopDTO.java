package com.plus.wine.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor

public class WineShopDTO {
    private Long wsno;
    private String wineshopname;
    private String address;
    private String tel;
}
