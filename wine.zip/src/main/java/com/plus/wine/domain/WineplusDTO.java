package com.plus.wine.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor

public class WineplusDTO {

    private Long no;
    private String type;
    private String country;
    private int price;
    private int sweet;
    private int sparkling;
    private int acidity;
    private int body;
    private int tannin;
    private String ofile;
    private String sfile;
    private String kname;
    private String ename;
    private String winery;
    private String vintage;
    private String volume;
    private String info;
    private int viewcount;
    private int min;
    private int max;
}
