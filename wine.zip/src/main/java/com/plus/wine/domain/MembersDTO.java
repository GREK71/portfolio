package com.plus.wine.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor

public class MembersDTO {
    private Long username;
    private String pw;
    private String sommelier;
    private String nickname;
}
