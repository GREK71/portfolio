package com.plus.wine.service;

import com.plus.wine.domain.Criteria;
import com.plus.wine.domain.WineplusDTO;
import com.plus.wine.mapper.WineplusMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Log4j2
@RequiredArgsConstructor
public class WineplusServiceImpl implements WineplusService {

    // mapper 자동주입
    private final WineplusMapper mapper;

    @Override
    public List<WineplusDTO> getList(){
        return mapper.getList();
    }

    @Override
    public List<WineplusDTO> selectWineList() {
        return mapper.selectWineList();
    }
//    @Override
//    public List<WineplusDTO> getList(Criteria cri) {
//        return mapper.getList();
//    }
//
//    @Override
//    public int getTotal(Criteria cri) {
//        return mapper.getTotalCount(cri);
//    }
}
