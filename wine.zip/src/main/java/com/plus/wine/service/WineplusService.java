package com.plus.wine.service;


import com.plus.wine.domain.Criteria;
import com.plus.wine.domain.WineplusDTO;

import java.util.List;

public interface WineplusService {

    // 리스트
    List<WineplusDTO> getList();

    List<WineplusDTO> selectWineList();
//    List<WineplusDTO> getList(Criteria cri);
//    int getTotal(Criteria cri);

}
