package com.plus.wine.mapper;

import com.plus.wine.domain.Criteria;
import com.plus.wine.domain.WineplusDTO;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface WineplusMapper {
    // 목록
    List<WineplusDTO> getList();

    List<WineplusDTO> selectWineList();

//    List<WineplusDTO> getListWithPaging(Criteria cri);
//    int getTotalCount(Criteria cri);
}
