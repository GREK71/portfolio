package com.plus.wine.controller;

import com.plus.wine.domain.Criteria;
import com.plus.wine.domain.PageDTO;
import com.plus.wine.service.WineplusService;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Slf4j
@Controller
@RequestMapping("/wineplus/*")
@Log4j2
@RequiredArgsConstructor
public class WineplusController {

    private final WineplusService service;

//    @GetMapping("/get/{id}")
//    public String getImage(@PathVariable Long id, Model model) {
//        // 이미지 상세 정보 조회 로직
//
////        model.addAttribute("image", image);
//        return "redirect:/wineplus/get)";
//    }
    @GetMapping("/index")
    public String index(){
        return null;
    }
    @GetMapping("/modify")
    public String modify(){
        return null;
    }
    @GetMapping("/detail")
    public String detail(){
        return null;
    }

//    @GetMapping("/list")
//    public void list(Criteria cri, Model model){
//        model.addAttribute("wine", service.getList(cri));
//
//        int total = service.getTotal(cri);
//
//        model.addAttribute("pageMaker", new PageDTO(cri, total));
//
//    }

    @GetMapping("/list")
    public void list(Model model){
        model.addAttribute("wine", service.getList());
    }
    @GetMapping("/login")
    public String login(){
        return "Hi Basic";
    }

}
